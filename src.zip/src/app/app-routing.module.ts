import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TablazatComponent } from './tablazat/tablazat.component';
import { Hiba404Component } from './hiba404/hiba404.component';

const routes: Routes = [
  {path: "tablazat", component: TablazatComponent},
  {path: "hiba404", component: Hiba404Component},
  {path: "", redirectTo: "/tablazat", pathMatch: "full"},
  {path: "**", component: TablazatComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
