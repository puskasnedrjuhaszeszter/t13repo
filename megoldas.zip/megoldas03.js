<script>
/*document.write("Puskásné dr. Juhász Eszter");
document.write("<br> #Team13");
document.write("<br> HTML: 100");
document.write("<br> CSS: 100");
document.write("<br> JavaScript: eddig 90");*/

let a=Number(prompt("Adj meg egy egész számot:"));
let b=Number(prompt("Adj meg egy nagyobb egész számot, hogy meddig legyen a tartomány:"));
document.write ('Páros számok az általad megadott tartományban:<br>')
let i=a;
while (i<=b){
if (i%2==0){
document.write (i+",");}
i++;}
</script>