<script>
/*document.write("Puskásné dr. Juhász Eszter");
document.write("<br> #Team13");
document.write("<br> HTML: 100");
document.write("<br> CSS: 100");
document.write("<br> JavaScript: eddig 90");*/

let kor=prompt ("Add meg az életkort:");
if (kor>0 && kor<=6){
document.write(`Kisgyermekkor`);
}
else if (kor>6 && kor<=12){
document.write(`Gyermekkor`);
}
else if (kor>12 && kor<=16){
document.write(`Serdülőkor`);
}
else if (kor>16 && kor<=20){
document.write(`Ifjúkor`);
}
else if (kor>20 && kor<=30){
document.write(`Fiatal felnőtt kor`);
}
else if (kor>30 && kor<=60){
document.write(`Felnőtt kor`);
}
else if (kor>60 && kor<=120){
document.write(`Aggkor`);
}
else {
document.write(`Hibás életkort adott meg!`);
}
</script>
