<script>
/*document.write("Puskásné dr. Juhász Eszter");
document.write("<br> #Team13");
document.write("<br> HTML: 100");
document.write("<br> CSS: 100");
document.write("<br> JavaScript: eddig 90");*/

let a=Number(prompt("Adj meg egy számot"));
let b=Number(prompt("Add meg a hatványozás mértékét"));
let osszeg=Math.pow (a, b);
document.write(`Az ${a} a ${b} hatványon:${osszeg}`);
</script>